"use client";

import React, { useEffect, useState, useMemo } from "react";
// ScrollProgress effect has been removed for mobile performance (reduced global layout shifts and calculation on scroll)
import { persistTrackingParams, submitLeadAndRedirect, trackPageView } from "@/utils/tracking";
import { initSession, trackStep } from "@/utils/analytics";
import { QuizProvider, useQuiz } from "@/context/QuizContext";
import dynamic from "next/dynamic";
import QuizFunnel from "@/components/quiz/QuizFunnel";
import Hero from "@/components/sections/Hero";
import Navbar from "@/components/Navbar";
import { useFunnelVersion } from "@/hooks/useFunnelVersion";
import Footer from "@/components/sections/Footer";
import ScrollObserver from "@/components/ui/ScrollObserver";

const QuizModal = dynamic(() => import("@/components/quiz/QuizModal"), { ssr: false });
const TrustBar = dynamic(() => import("@/components/sections/TrustBar"), { ssr: false });
const Problem = dynamic(() => import("@/components/sections/Problem"), { ssr: false });
const Features = dynamic(() => import("@/components/sections/Features"), { ssr: false });
const MobileApp = dynamic(() => import("@/components/sections/MobileApp"), { ssr: false });
const Ranking = dynamic(() => import("@/components/sections/Ranking"), { ssr: false });
const Rewards = dynamic(() => import("@/components/sections/Rewards"), { ssr: false });
const OfferBlock = dynamic(() => import("@/components/sections/OfferBlock"), { ssr: false });
const FAQ = dynamic(() => import("@/components/sections/FAQ"), { ssr: false });

function PageContent() {
  const { isHydrated, quizCompleted, quizData, leadData } = useQuiz();
  const [showQuizModal, setShowQuizModal] = useState(false);

  const { isV1, isV2, isV3 } = useFunnelVersion();

  // Persist UTM/tracking params on first load
  useEffect(() => {
    persistTrackingParams();
  }, []);

  // Fire Pageview event for GTM/Pixel once hydrated (ensures reliable param capture)
  // And initialize the internal Supabase session (Visitor tracking)
  useEffect(() => {
    if (isHydrated) {
      const version = isV3 ? 'v3' : isV2 ? 'v2' : 'v1';
      
      // 1. External Analytics (GTM/Meta)
      trackPageView(version);
      
      // 2. Internal Analytics (Supabase Visitors)
      initSession(version).then(() => {
        // Se for v2 ou v3, iniciamos o step 0 (hero) direto na landing page.
        // A v1 vai delegar isso para o QuizFunnel.
        if (!isV1) {
          trackStep(0, 'enter');
        }
      });
    }
  }, [isHydrated, isV1, isV2, isV3]);

  // V2/V3: Monitora encerramento da janela (bounce na home)
  useEffect(() => {
    if (!isV1 && isHydrated) {
      const handleUnload = () => {
        import('@/utils/analytics').then(m => m.endSessionBeacon(0));
      };
      window.addEventListener('beforeunload', handleUnload);
      return () => window.removeEventListener('beforeunload', handleUnload);
    }
  }, [isV1, isHydrated]);

  // V1: WhatsApp CTA handler (after quiz gate)
  const handleWhatsAppCTA = (source: string) => {
    if (!leadData) return;
    submitLeadAndRedirect(leadData, source, quizData);
  };

  // V2: CTA opens quiz modal
  const handleV2CTA = (_source: string) => {
    setShowQuizModal(true);
  };

  // Wait for client-side sessionStorage hydration
  // Em vez de retornar null para o SSR da V1, retornamos a tela inicial do Quiz, garantindo que o Hero chegue pré-renderizado no HTML puro, derrubando o LCP.
  if (isV1 && !isHydrated) return <QuizFunnel mode="gate" />;
  if (isV1) {
    if (!quizCompleted) {
      return <QuizFunnel mode="gate" />;
    }

    return (
      <>
        <Navbar onCTA={handleWhatsAppCTA} />
        <main className="relative z-10">
          <Hero onCTA={handleWhatsAppCTA} />
          <Features onCTA={handleWhatsAppCTA} />
          <TrustBar />
          <Problem />
          <MobileApp onCTA={handleWhatsAppCTA} />
          <Ranking onCTA={handleWhatsAppCTA} />
          <Rewards onCTA={handleWhatsAppCTA} />
          <OfferBlock onCTA={handleWhatsAppCTA} />
          <FAQ />
        </main>
        <Footer onCTA={handleWhatsAppCTA} />
      </>
    );
  }

  // ── V2 & V3: Landing Page → CTA opens Quiz Modal → WhatsApp / Trial ──
  return (
    <>
      <Navbar onCTA={handleV2CTA} />
      <main className="relative z-10">
        <Hero onCTA={handleV2CTA} />
        <Features onCTA={handleV2CTA} />
        <TrustBar />
        <Problem />
        <MobileApp onCTA={handleV2CTA} />
        <Ranking onCTA={handleV2CTA} />
        <Rewards onCTA={handleV2CTA} />
        <OfferBlock onCTA={handleV2CTA} />
        <FAQ />
      </main>
      <Footer onCTA={handleV2CTA} />

      <QuizModal
        isOpen={showQuizModal}
        onClose={() => setShowQuizModal(false)}
      />
    </>
  );
}

export default function PageClient() {
  return (
    <QuizProvider>
      <ScrollObserver />
      <PageContent />
    </QuizProvider>
  );
}
